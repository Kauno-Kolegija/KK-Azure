'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createServer, isPublicDemo } = require('../server');
const config = require('../site.json');

async function withServer(options, cb) {
  const server = createServer(options);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  try { await cb(`http://127.0.0.1:${server.address().port}`); }
  finally { await new Promise(resolve => server.close(resolve)); }
}
const baseConfig = { ...config, showKeyVaultCard: false };
const vaultConfig = { ...config, showKeyVaultCard: true };

test('site.json turi tinkama X.Y versija ir tekstus', () => {
  assert.match(config.version, /^[1-9]\d*\.\d+$/);
  assert.ok(typeof config.headline === 'string' && config.headline.length >= 5);
  assert.ok(typeof config.featureText === 'string' && config.featureText.length >= 8);
  assert.ok(typeof config.showKeyVaultCard === 'boolean');
});

test('/health veikia net kai nera Key Vault konfigūracijos', async () => {
  await withServer({ labMessage: '', siteConfig: vaultConfig }, async base => {
    const res = await fetch(`${base}/health`);
    const data = await res.json();
    assert.equal(res.status, 200);
    assert.equal(data.status, 'ok');
    assert.equal(data.version, config.version);
    assert.equal(data.keyVaultConfigLoaded, false);
  });
});

test('/ready 200 kai Key Vault funkcija dar neijungta', async () => {
  await withServer({ labMessage: '', siteConfig: baseConfig }, async base => {
    const res = await fetch(`${base}/ready`);
    assert.equal(res.status, 200);
    assert.equal((await res.json()).keyVaultRequired, false);
  });
});

test('/ready 503 kai Key Vault funkcijai truksta konfigūracijos', async () => {
  await withServer({ labMessage: '', siteConfig: vaultConfig }, async base => {
    const res = await fetch(`${base}/ready`);
    assert.equal(res.status, 503);
    assert.equal((await res.json()).status, 'not-ready');
  });
});

test('/ready 200 kai yra tinkama DEMO konfiguracija', async () => {
  await withServer({ labMessage: 'DEMO-Mano pirmasis DevOps projektas!', siteConfig: vaultConfig }, async base => {
    const res = await fetch(`${base}/ready`);
    const data = await res.json();
    assert.equal(res.status, 200);
    assert.equal(data.demoMessageVisible, true);
  });
});

test('V1 ir V2 nerodo Key Vault korteles', async () => {
  await withServer({ labMessage: '', siteConfig: baseConfig }, async base => {
    const html = await (await fetch(base)).text();
    assert.ok(!html.includes('Key Vault demonstracija'));
    assert.ok(html.includes(`VERSIJA ${config.version}`));
  });
});

test('V3 rodo Key Vault priklausomybes ispejima', async () => {
  await withServer({ labMessage: '', siteConfig: vaultConfig }, async base => {
    const html = await (await fetch(base)).text();
    assert.ok(html.includes('Key Vault demonstracija'));
    assert.ok(html.includes('Trūksta priklausomybės'));
  });
});

test('DEMO tekstas su tarpais ir lietuviskomis raidemis saugiai rodomas', async () => {
  const msg = 'DEMO-Sveiki, studentai! Šaunus DevOps & <test>.';
  assert.equal(isPublicDemo(msg), true);
  await withServer({ labMessage: msg, siteConfig: vaultConfig }, async base => {
    const html = await (await fetch(base)).text();
    assert.ok(html.includes('DEMO-Sveiki, studentai!'));
    assert.ok(html.includes('&amp; &lt;test&gt;'));
    assert.ok(!html.includes('<test>'));
  });
});

test('be DEMO prefikso reiksme viesai neparodoma', async () => {
  const secret = 'tikras-slaptazodis-neturi-buti-rodomas';
  await withServer({ labMessage: secret, siteConfig: vaultConfig }, async base => {
    const html = await (await fetch(base)).text();
    const ready = await fetch(`${base}/ready`);
    assert.ok(!html.includes(secret));
    assert.equal(ready.status, 503);
    assert.equal((await ready.json()).keyVaultConfigLoaded, true);
  });
});

test('CSS pasiekiamas, o nezinomas URL grazina 404', async () => {
  await withServer({ labMessage: '', siteConfig: baseConfig }, async base => {
    const css = await fetch(`${base}/styles.css`);
    assert.equal(css.status, 200);
    assert.match(await css.text(), /\.hero/);
    const missing = await fetch(`${base}/not-found`);
    assert.equal(missing.status, 404);
  });
});
