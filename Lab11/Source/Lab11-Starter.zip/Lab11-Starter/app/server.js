'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const defaultConfig = require('./site.json');
const css = fs.readFileSync(path.join(__dirname, 'public', 'styles.css'), 'utf8');

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[ch]);
}
function safeColor(value, fallback) {
  return /^#[0-9a-fA-F]{6}$/.test(String(value)) ? value : fallback;
}
function isPublicDemo(value) {
  // Educational guardrail, NOT a security boundary. Never put real secrets here.
  return typeof value === 'string' &&
    value.startsWith('DEMO-') && value.length > 5 && value.length <= 200 &&
    !/[\x00-\x1F\x7F]/.test(value);
}
function createServer({ labMessage = process.env.LAB_MESSAGE, siteConfig = defaultConfig } = {}) {
  const hasConfig = Boolean(labMessage);
  const publicDemo = isPublicDemo(labMessage) ? labMessage : null;
  const needsKeyVault = siteConfig.showKeyVaultCard === true;
  const ready = !needsKeyVault || Boolean(publicDemo);
  const demoVisible = needsKeyVault && Boolean(publicDemo);
  const version = siteConfig.version;

  return http.createServer((req, res) => {
    if (req.url === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify({
        status: 'ok', version,
        keyVaultConfigLoaded: hasConfig,
        demoMessageVisible: demoVisible
      }));
      return;
    }
    if (req.url === '/ready') {
      res.writeHead(ready ? 200 : 503, {
        'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'
      });
      res.end(JSON.stringify({
        status: ready ? 'ready' : 'not-ready', version,
        keyVaultRequired: needsKeyVault,
        keyVaultConfigLoaded: hasConfig,
        demoMessageVisible: demoVisible
      }));
      return;
    }
    if (req.url === '/styles.css') {
      res.writeHead(200, { 'Content-Type': 'text/css; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(css);
      return;
    }
    if (req.url !== '/') {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }

    const items = Array.isArray(siteConfig.highlights) ? siteConfig.highlights : [];
    const features = items.map(x => `<li>${escapeHtml(x)}</li>`).join('');
    const vaultState = !hasConfig ? 'Laukiama infrastruktūros ir konfigūracijos'
      : publicDemo ? `Gauta demonstracinė reikšmė: <code>${escapeHtml(publicDemo)}</code>`
        : 'Konfigūracija yra, tačiau jos reikšmė netinka DEMO- formatui';
    const vaultFlag = ready ? 'Integracija paruošta' : 'Trūksta priklausomybės';
    const vaultStatus = ready ? 'success' : 'warning';
    const vaultCard = needsKeyVault ? `<section class="vault vault-${vaultStatus}">
      <div class="vault-heading"><h2>Key Vault demonstracija</h2><span class="state">${vaultFlag}</span></div>
      <p>${vaultState}</p>
      <small>DĖMESIO: Azure CLI nukopijuoja DEMO reikšmę iš Key Vault į App Service LAB_MESSAGE. Svetainė prie Key Vault tiesiogiai nesijungia.</small>
    </section>` : '';
    const accent = safeColor(siteConfig.accent, '#2563eb');
    const soft = safeColor(siteConfig.accentSoft, '#dbeafe');
    const now = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const host = process.env.WEBSITE_SITE_NAME || 'vietinė / testavimo aplinka';

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(`<!doctype html><html lang="lt"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>LAB11 | DevOps CI/CD</title><link rel="stylesheet" href="/styles.css"></head>
<body style="--accent:${accent};--accentSoft:${soft}"><div class="shell">
<!-- <nav class="nav"><div class="brand">LAB11 / DEVOPS</div><div class="tag">GitHub Actions · Azure</div></nav> -->
<header class="hero"><p class="eyebrow">${escapeHtml(siteConfig.heroBadge || 'GYVA SVETAINĖ')}</p>
<h1>${escapeHtml(siteConfig.headline)}</h1><p class="lead">${escapeHtml(siteConfig.subtitle)}</p>
<div class="pills">
  <span class="pill">VERSIJA ${escapeHtml(version)}</span>
  <span class="pill">${escapeHtml(siteConfig.owner)}</span>
  <a class="pill" href="/health" target="_blank" rel="noopener noreferrer">/health</a>
  <a class="pill" href="/ready" target="_blank" rel="noopener noreferrer">/ready</a>
</div></header>
<section class="grid"><div class="card"><div class="card-label">Paskutinis pakeitimas</div><div class="card-value">${escapeHtml(siteConfig.releaseNote)}</div><small>Redaguokite app/site.json ir atlikite git push</small></div>
<div class="card"><div class="card-label">Azure App Service</div><div class="card-value">${escapeHtml(host)}</div><small>Node.js 22 · GitHub Actions</small></div>
<div class="card"><div class="card-label">Serverio laikas</div><div class="card-value">${escapeHtml(now)}</div><small>Atnaujinkite puslapį, kad matytumėte kitą laiką</small></div></section>
<section class="spotlight"><div class="spotlight-icon">✦</div><div><div class="spotlight-title">${escapeHtml(siteConfig.featureTitle || 'Komandos pranešimas')}</div><p>${escapeHtml(siteConfig.featureText || 'Pirmasis DevOps leidimas')}</p></div></section>
<!-- <section class="detail"><h2>Šio leidimo galimybės</h2><ul>${features}</ul></section> -->
${vaultCard}
</div></body></html>`);
  });
}

if (require.main === module) {
  const port = Number(process.env.PORT || 8080);
  createServer().listen(port, '0.0.0.0', () => console.log(`LAB11 app on port ${port}`));
}
module.exports = { createServer, isPublicDemo, escapeHtml };
