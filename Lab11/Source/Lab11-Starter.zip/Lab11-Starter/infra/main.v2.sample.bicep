// LAB11 V2. Same Web App/Plan as V1, adds ONE Key Vault (no secrets in Git).
// Entra object ID (not a secret) is passed from Azure CLI to grant DEMO-secret permissions.
// Do not force a soft-delete retention period: it is immutable after Key Vault creation.
// New vaults use the Azure default retention; soft-deleted vault names may need recovery.
param location string = resourceGroup().location
@description('Microsoft Entra user Object ID (not a secret), from az ad signed-in-user show --query id -o tsv')
param operatorObjectId string

var suffix = uniqueString(resourceGroup().id)
var appName = 'lab11${suffix}'
var planName = 'plan-lab11-${suffix}'
var keyVaultName = 'kv11-${suffix}'

resource appPlan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: planName
  location: location
  kind: 'linux'
  sku: {
    name: 'B1'
    tier: 'Basic'
  }
  properties: {
    reserved: true
  }
}

resource webApp 'Microsoft.Web/sites@2023-12-01' = {
  name: appName
  location: location
  kind: 'app,linux'
  properties: {
    serverFarmId: appPlan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: 'NODE|22-lts'
      alwaysOn: true
      ftpsState: 'Disabled'
      appCommandLine: 'npm start'
    }
  }
}

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: keyVaultName
  location: location
  properties: {
    tenantId: subscription().tenantId
    sku: {
      family: 'A'
      name: 'standard'
    }
    enableRbacAuthorization: false
    accessPolicies: [
      {
        tenantId: subscription().tenantId
        objectId: operatorObjectId
        permissions: {
          secrets: [
            'get'
            'list'
            'set'
          ]
        }
      }
    ]
  }
}

output webAppName string = webApp.name
output webAppUrl string = 'https://${webApp.properties.defaultHostName}'
output appServicePlanName string = appPlan.name
output uniqueSuffix string = suffix
output keyVaultName string = keyVault.name
