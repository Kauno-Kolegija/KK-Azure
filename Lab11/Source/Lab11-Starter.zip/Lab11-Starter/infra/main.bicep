// LAB11 V1. Manual Azure CLI deployment. All resource names are lower-case and stable.
param location string = resourceGroup().location

var suffix = uniqueString(resourceGroup().id)
var appName = 'lab11${suffix}'
var planName = 'plan-lab11-${suffix}'

resource appPlan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: planName
  location: location
  kind: 'linux'
  sku: {
    name: 'B1'
    tier: 'Basic'
  }
  properties: {
    reserved: true
  }
}

resource webApp 'Microsoft.Web/sites@2023-12-01' = {
  name: appName
  location: location
  kind: 'app,linux'
  properties: {
    serverFarmId: appPlan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: 'NODE|22-lts'
      alwaysOn: true
      ftpsState: 'Disabled'
      appCommandLine: 'npm start'
    }
  }
}

output webAppName string = webApp.name
output webAppUrl string = 'https://${webApp.properties.defaultHostName}'
output appServicePlanName string = appPlan.name
output uniqueSuffix string = suffix
