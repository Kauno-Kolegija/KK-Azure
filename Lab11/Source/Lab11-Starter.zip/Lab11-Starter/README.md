# LAB11 / Azure: DevOps su Git, GitHub Actions, Bicep ir Key Vault

Tai mokomasis starter projektas, skirtas dirbti **VS Code PowerShell** terminale.
Node.js **nereikia** instaliuoti studento kompiuteryje: CI atlieka `npm ci` ir `npm test` GitHub runner.

## Failu struktura

- `.github/workflows/app.yml` - aplikacijos CI (10 testu) ir CD (tik push i `main`).
- `.github/workflows/infra.yml` - automatine Bicep build/lint patikra; Azure What-If **pasirinktinis**, reikalauja OIDC.
- `.github/scripts/` - saugus publikavimo konfiguracijos ir /health versijos tikrinimas.
- `infra/main.bicep` - V1: App Service Plan + Web App.
- `infra/main.v2.sample.bicep` - V2: tie patys Web App ir Plan + Key Vault; paslapciu *nekuria*.
- `app/site.json` - studentui atviri website V1 -> V2 -> V3 -> V4 tekstai, spalvos ir funkciju jungikliai.
- `app/server.js`, `app/public/styles.css` - svetaines kodas su `/health` (visada 200) ir `/ready` (503 jei V3 neturi LAB_MESSAGE).
- `app/test/server.test.js` - 10 automatiniu testu.

## Pradzios seka

1. GitHub sukurkite **tuscia** `Lab11-devops` privacia repozitorija (be README).
2. Is terminalo `az login` ir Bicep V1 sukurkite Azure App Service; pasiimkite `webAppName` output.
3. Nustatykite GitHub `AZURE_WEBAPP_NAME` kaip **Repository Variable**, Publish Profile XML kaip `AZURE_WEBAPP_PUBLISH_PROFILE` **Repository Secret**.
4. `git init -b main`, `git add .`, `git commit`, `git push`: paleis `app.yml` ir `infra.yml`.
5. V2 ir V3 pakeitimus darykite **tik** `app/site.json` ir stebekite publikavima.
6. V3 ijunkite `showKeyVaultCard: true`: `/ready` grązins 503. Tai numatyta demonstracija, o ne CI/CD klaida.
7. Bicep V2 sukuriamas Key Vault, pirmoji **DEMO-** paslaptis ikeliama per Azure CLI, tada perduodama i `LAB_MESSAGE` App Service setting. Naujas versijas kurkite Key Vault portale ir perskaitykite / perduokite per CLI is naujo.
8. Baigus isvalykite Azure RG ir GitHub Publish Profile Secret.

## Svarbus autentifikacijos niuansas

**Publish Profile negali vykdyti ARM What-If.** `infra.yml` be Azure prisijungimo automatiskai tikrina Bicep sintakse. `workflow_dispatch` + OIDC gali paleisti tikra Azure What-If, jeigu destytojas/studentas turi teises sukurti federuota tapatybe ir prideti `AZURE_CLIENT_ID`, `AZURE_TENANT_ID`, `AZURE_SUBSCRIPTION_ID` Secrets.

Bazineje uzduotyje `az deployment group what-if` ir `az deployment group create` paleidziami **tik per studento PowerShell po `az login`**. GitHub Actions infrastruktūros **nekuria**.

## Saugumas

`DEMO-` yra tik mokomoji reikšme ir **ne slaptu duomenu apsauga**. Jokiu realiu slaptazodziu nepridėkite nei i Key Vault `lab-message`, nei i Git, nei i viesai rodomus puslapio laukus. Po patikrinimo istrinkite Publish Profile Secret ir istekliu grupe. B1 planas apmokestinamas.
