"""Retry Azure /health until the live release matches app/site.json."""
import json
import os
import sys
import time
import urllib.error
import urllib.request

app = os.environ["AZURE_WEBAPP_NAME"].strip()
with open("app/site.json", encoding="utf-8") as stream:
    expected = json.load(stream)["version"]
url = f"https://{app}.azurewebsites.net/health"
for attempt in range(1, 13):
    try:
        with urllib.request.urlopen(url, timeout=12) as response:
            data = json.load(response)
        actual = data.get("version")
        if data.get("status") == "ok" and actual == expected:
            print(f"OK: Azure website is live, version {actual}.")
            sys.exit(0)
        print(f"Attempt {attempt}: waiting for version {expected}; currently {actual}.")
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        print(f"Attempt {attempt}: website not ready ({type(exc).__name__}).")
    time.sleep(10)
sys.exit(f"ERROR: Azure site did not return expected version {expected}. Check App Service logs.")
