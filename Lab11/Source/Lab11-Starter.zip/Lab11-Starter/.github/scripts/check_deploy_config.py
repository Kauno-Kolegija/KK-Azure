"""Validate public deployment metadata. Never print publish profile content."""
import os
import re
import sys
import xml.etree.ElementTree as ET

app = os.getenv("AZURE_WEBAPP_NAME", "").strip()
xml = os.getenv("PUBLISH_PROFILE", "").strip()
if not app:
    sys.exit("ERROR: GitHub Actions variable AZURE_WEBAPP_NAME is empty.")
if not re.fullmatch(r"[a-zA-Z0-9-]{2,60}", app):
    sys.exit("ERROR: AZURE_WEBAPP_NAME must be a resource name, NOT a https:// URL.")
if not xml:
    sys.exit("ERROR: GitHub Actions secret AZURE_WEBAPP_PUBLISH_PROFILE is empty.")
try:
    root = ET.fromstring(xml)
except ET.ParseError:
    sys.exit("ERROR: Publish Profile is not valid XML.")
profiles = [p for p in root.findall(".//publishProfile")
            if p.get("publishMethod") in ("MSDeploy", "ZipDeploy")]
if not profiles:
    sys.exit("ERROR: Missing MSDeploy/ZipDeploy in Publish Profile.")
if not any(p.get("userName", "").lower() == ("$" + app).lower() for p in profiles):
    sys.exit("ERROR: Publish Profile belongs to another App Service. Download it again.")
print("OK: App Service resource name and Publish Profile match. No secrets shown.")
